import { createGlobalStyle } from 'styled-components';

const GlobalStyle = createGlobalStyle`
  @font-face {
    font-family: 'Inter var';
    font-weight: 100 900;
    font-style: normal;
    font-display: swap;
    src: url('/fonts/Inter-Variable.woff2') format('woff2');
  }

  :root {
    --bg: ${({ theme }) => theme.colors.bg};
    --surface: ${({ theme }) => theme.colors.surface};
    --elev: ${({ theme }) => theme.colors.elev};
    --text: ${({ theme }) => theme.colors.text};
    --muted: ${({ theme }) => theme.colors.muted};
    --border: ${({ theme }) => theme.colors.border};
    --pri: ${({ theme }) => theme.colors.pri};
    --succ: ${({ theme }) => theme.colors.succ};
    --warn: ${({ theme }) => theme.colors.warn};
    --err: ${({ theme }) => theme.colors.err};

    --r-sm: 6px; --r-md: 8px; --r-lg: 12px; --r-xl: 16px;
    --t-fast: 120ms; --t-med: 180ms; --t-slow: 240ms;
    
    /* Text sizes */
    --text-xs: 0.75rem;
    --text-sm: 0.875rem;
    --text-base: 1rem;
    --text-lg: 1.125rem;
    --text-xl: 1.25rem;
    --text-2xl: 1.5rem;
    --text-3xl: 1.875rem;
    
    /* Spacing */
    --space-xs: 0.25rem;
    --space-sm: 0.5rem;
    --space-md: 1rem;
    --space-lg: 1.5rem;
    --space-xl: 2rem;
    --space-2xl: 3rem;
  }

  html, body, #root { height: 100%; }
  body {
    margin: 0; 
    background: var(--bg); 
    color: var(--text);
    font-family: 'Inter var', Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    -webkit-font-smoothing: antialiased; 
    -moz-osx-font-smoothing: grayscale;
    /* Ensure premium dark theme is always enforced */
    background-color: #0F0A1E !important;
    color: #F8FAFC !important;
  }
  
  /* Force dark theme across all elements */
  *, *::before, *::after {
    border-color: var(--border);
  }
  
  * { box-sizing: border-box; }
  a { color: inherit; text-decoration: none; }
  .text-muted { color: var(--muted); }
  .hairline { border: 1px solid var(--border); }

  /* Typography scale - modern, crisp, and well-spaced */
  h1 { 
    font-size: var(--text-3xl);
    font-weight: 700; 
    line-height: 1.2; 
    letter-spacing: -0.025em;
    margin-bottom: 1rem;
  }
  h2 { 
    font-size: var(--text-2xl);
    font-weight: 600; 
    line-height: 1.25; 
    letter-spacing: -0.02em;
    margin-bottom: 0.75rem;
  }
  h3 { 
    font-size: var(--text-xl);
    font-weight: 600; 
    line-height: 1.3; 
    letter-spacing: -0.015em;
    margin-bottom: 0.5rem;
  }
  
  p, body { 
    font-size: var(--text-base);
    line-height: 1.6;
    margin-bottom: 1rem;
  }
  
  .text-small { 
    font-size: var(--text-sm);
    line-height: 1.5;
  }

  /* Focus styles for accessibility */
  *:focus-visible {
    outline: 2px solid var(--pri);
    outline-offset: 2px;
    border-radius: calc(var(--r-md) + 2px);
  }

  /* Reduced motion support */
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
    }
  }

  /* Fallback styles for when custom font fails to load */
  .font-loading-error {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif !important;
  }

  /* Ensure the app renders even with styling issues */
  #root {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
  }

  /* Basic button reset for accessibility */
  button {
    cursor: pointer;
    border: none;
    background: none;
    font-family: inherit;
  }

  button:disabled {
    cursor: not-allowed;
    opacity: 0.6;
  }

  /* ========== ACCESSIBILITY TOOLBAR STYLES ========== */
  
  /* Large text styles */
  .a11y-large-text {
    font-size: 1.125rem !important;
    line-height: 1.7 !important;
  }
  
  .a11y-large-text p,
  .a11y-large-text span,
  .a11y-large-text div,
  .a11y-large-text button,
  .a11y-large-text input,
  .a11y-large-text label {
    font-size: 1.125rem !important;
    line-height: 1.7 !important;
  }
  
  .a11y-large-text h1 { font-size: 2.25rem !important; }
  .a11y-large-text h2 { font-size: 2rem !important; }
  .a11y-large-text h3 { font-size: 1.75rem !important; }
  .a11y-large-text h4 { font-size: 1.5rem !important; }
  .a11y-large-text h5 { font-size: 1.25rem !important; }
  .a11y-large-text h6 { font-size: 1.125rem !important; }
  
  /* Extra large text styles */
  .a11y-xlarge-text {
    font-size: 1.25rem !important;
    line-height: 1.8 !important;
  }
  
  .a11y-xlarge-text p,
  .a11y-xlarge-text span,
  .a11y-xlarge-text div,
  .a11y-xlarge-text button,
  .a11y-xlarge-text input,
  .a11y-xlarge-text label {
    font-size: 1.25rem !important;
    line-height: 1.8 !important;
  }
  
  .a11y-xlarge-text h1 { font-size: 2.5rem !important; }
  .a11y-xlarge-text h2 { font-size: 2.25rem !important; }
  .a11y-xlarge-text h3 { font-size: 2rem !important; }
  .a11y-xlarge-text h4 { font-size: 1.75rem !important; }
  .a11y-xlarge-text h5 { font-size: 1.5rem !important; }
  .a11y-xlarge-text h6 { font-size: 1.25rem !important; }
  
  /* High contrast styles */
  .a11y-high-contrast {
    filter: contrast(150%) brightness(110%) !important;
  }
  
  .a11y-high-contrast * {
    background-color: var(--contrast-bg, inherit) !important;
    color: var(--contrast-text, inherit) !important;
    border-color: var(--contrast-border, inherit) !important;
  }
  
  /* Override specific elements for high contrast */
  .a11y-high-contrast button {
    background-color: #000000 !important;
    color: #ffffff !important;
    border: 2px solid #ffffff !important;
  }
  
  .a11y-high-contrast button:hover {
    background-color: #ffffff !important;
    color: #000000 !important;
  }
  
  .a11y-high-contrast input,
  .a11y-high-contrast textarea,
  .a11y-high-contrast select {
    background-color: #ffffff !important;
    color: #000000 !important;
    border: 2px solid #000000 !important;
  }
  
  /* Reduced motion styles */
  .a11y-reduced-motion,
  .a11y-reduced-motion * {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    transform: none !important;
  }
  
  /* Dyslexia-friendly font */
  .a11y-dyslexia-font,
  .a11y-dyslexia-font * {
    font-family: 'Comic Sans MS', 'Arial', sans-serif !important;
    font-weight: 400 !important;
    letter-spacing: 0.05em !important;
    word-spacing: 0.1em !important;
  }
  
  /* Ensure focus is always visible in accessibility modes */
  .a11y-large-text *:focus,
  .a11y-xlarge-text *:focus,
  .a11y-high-contrast *:focus {
    outline: 3px solid #ffff00 !important;
    outline-offset: 3px !important;
  }

  /* 
   * Accessibility fixes for third-party components
   * These override low-contrast elements from external libraries like Stripe
   */
  
  /* Fix contrast for cursor pointer labels */
  label[class*="aiinhbfoop"][class*="cursor-pointer"] {
    color: #212529 !important; /* Dark text for better contrast */
    font-weight: 500 !important; /* Slightly bolder for better readability */
  }
  
  /* Fix contrast for pricing buttons */
  button[id*="aiinhbfoop-pricing"],
  button[class*="aiinhbfoop"][class*="text-neutral"] {
    background-color: #198754 !important; /* High contrast green background */
    color: #ffffff !important; /* White text for maximum contrast */
    border: 1px solid #146c43 !important; /* Darker border */
  }
  
  button[id*="aiinhbfoop-pricing"]:hover,
  button[class*="aiinhbfoop"][class*="text-neutral"]:hover {
    background-color: #146c43 !important; /* Darker on hover */
    color: #ffffff !important;
  }
  
  /* Fix contrast for small text spans */
  span[class*="aiinhbfoop"][class*="text-xs"],
  span[class*="aiinhbfoop"][class*="font-medium"][class*="opacity-60"] {
    color: #212529 !important; /* Dark text instead of low opacity */
    opacity: 1 !important; /* Remove problematic opacity */
    font-weight: 600 !important; /* Bolder font for better readability */
  }
  
  /* General fix for any low-contrast aiinhbfoop elements */
  [class*="aiinhbfoop"][class*="text-neutral-500"] {
    color: #343a40 !important; /* Darker neutral color */
  }
  
  [class*="aiinhbfoop"][class*="opacity-60"] {
    opacity: 0.9 !important; /* Less transparent for better readability */
  }
  
  /* Ensure sufficient contrast for any third-party pricing components */
  stripe-pricing-table * {
    color: inherit;
  }
  
  stripe-pricing-table button,
  stripe-pricing-table [role="button"] {
    background-color: #198754 !important;
    color: #ffffff !important;
    border: 1px solid #146c43 !important;
    font-weight: 500 !important;
  }
  
  stripe-pricing-table button:hover,
  stripe-pricing-table [role="button"]:hover {
    background-color: #146c43 !important;
    color: #ffffff !important;
  }
`;

export default GlobalStyle;